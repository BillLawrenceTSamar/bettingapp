package com.example.myapplication;

import androidx.core.content.FileProvider;

public class GenericFileProvider extends FileProvider {}

