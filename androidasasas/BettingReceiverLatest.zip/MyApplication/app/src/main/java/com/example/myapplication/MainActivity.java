package com.example.myapplication;

import androidx.annotation.ColorInt;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.FileProvider;


import android.app.AlertDialog;
import android.content.ContentValues;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Color;
import android.hardware.usb.UsbAccessory;
import android.media.MediaPlayer;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.os.StrictMode;
import android.provider.Telephony;
import android.telephony.SmsManager;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TabHost;
import android.widget.TextView;
import android.widget.Toast;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.net.URISyntaxException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

import com.github.nkzawa.socketio.client.Ack;
import com.github.nkzawa.socketio.client.IO;
import com.github.nkzawa.socketio.client.Socket;
import com.github.nkzawa.emitter.Emitter;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import android.hardware.usb.UsbManager;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        StrictMode.VmPolicy.Builder builder = new StrictMode.VmPolicy.Builder();
        StrictMode.setVmPolicy(builder.build());
        initializeComponents();
        initializeDatabase();

        mp = MediaPlayer.create(getApplicationContext(), RingtoneManager.getActualDefaultRingtoneUri(MainActivity.this, RingtoneManager.TYPE_NOTIFICATION));
        sr = new SMSReceiver(this);
        smsManager = SmsManager.getDefault();

        IntentFilter fltr_smsreceived = new IntentFilter("android.provider.Telephony.SMS_RECEIVED");
        registerReceiver(sr,fltr_smsreceived);

        updateSyncCounterWidget(countUnsyncedMessages());
    }

    @Override
    public void onDestroy() {
        smsManager = null;

        mp.release();
        mp = null;

        unregisterReceiver(sr);
        sr = null;

        mSocket.disconnect();
        mSocket.io().off();

        mSocket = null;
        super.onDestroy();
    }

    @Override
    public void onBackPressed() {
        new AlertDialog.Builder(this)
                .setIcon(android.R.drawable.ic_dialog_alert)
                .setTitle("SMS Bridge")
                .setMessage("Are you sure you want to close the bridge?\nThe phone will no longer be able to record and forward bets to the betting server.")
                .setPositiveButton("Yes", new DialogInterface.OnClickListener()
                {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        finish();
                    }

                })
                .setNegativeButton("No", null)
                .show();
    }

    private void initializeComponents() {

        setContentView(R.layout.activity_main);

        tv_no_bets = findViewById(R.id.tv_no_bets);
        tv_unsynced_bets = findViewById(R.id.tv_unsynced_bets);

        et_action_log = findViewById(R.id.et_action_log);
        et_host_address = findViewById(R.id.et_host_address);
        et_host_address.setText(HOST_ADDRESS);
        et_host_port = findViewById(R.id.et_host_port);
        et_host_port.setText(HOST_PORT);
        et_draw_category = findViewById(R.id.et_draw_category);
        et_draw_category.setText(DRAW_CATEGORY);
        et_send_to_server = findViewById(R.id.et_send_to_server);

        try {
            JSONObject JO = new JSONObject(JSONFileManager.getData(this));
            HOST_ADDRESS = JO.getString("host_address");
            HOST_PORT = JO.getString("host_port");
            DRAW_CATEGORY = JO.getString("draw_category");

            et_host_address.setText(HOST_ADDRESS);
            et_host_port.setText(HOST_PORT);
            et_host_port.setText(DRAW_CATEGORY);
        } catch(Exception e) {
            Toast.makeText(this,e.getMessage(),Toast.LENGTH_SHORT).show();
        }

        btn_view_logs = findViewById(R.id.btn_view_logs);
        btn_view_logs.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                //Intent intent = new Intent(Intent.ACTION_VIEW, Uri.fromFile(new File(Environment.getExternalStorageDirectory().toString() + "/bridgelog.txt")));
               // intent.setType("text/html");

               // startActivity(intent);
                Uri fileURI = Uri.fromFile(new File(Environment.getExternalStorageDirectory().toString() + "/bridgelog.txt"));
              // Uri fileURI = FileProvider.getUriForFile(MainActivity.this, MainActivity.this.getApplicationContext().getPackageName() + ".provider", new File(Environment.getExternalStorageDirectory().toString()  + "/bridgelog.txt"));
                //Toast.makeText(MainActivity.this,fileURI.getPath(),Toast.LENGTH_LONG).show();
                Intent myIntent = new Intent(android.content.Intent.ACTION_VIEW);
                String extension = android.webkit.MimeTypeMap.getFileExtensionFromUrl(fileURI.toString());
                String mimetype = android.webkit.MimeTypeMap.getSingleton().getMimeTypeFromExtension(extension);
                myIntent.setDataAndType(fileURI,mimetype);
                startActivity(myIntent);
            }
        });

        btn_1 = findViewById(R.id.btn_1);

        btn_1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //getAllSms();
                initializeSockets();
            }
        });

        btn_clear_app_db_cache = findViewById(R.id.btn_clear_app_db_cache);
        btn_clear_app_db_cache.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                DB.delete("messages",null,null);
                updateSyncCounterWidget(countUnsyncedMessages());
                Toast.makeText(MainActivity.this, "SMS Bridge Data Cleared!", Toast.LENGTH_LONG).show();
                create_activity_log("SYSTEM DATA","SMS Bridge Data Cleared by user");
            }
        });

        btn_save_settings = findViewById(R.id.btn_save_settings);
        btn_save_settings.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                HOST_ADDRESS = et_host_address.getText().toString();
                HOST_PORT = et_host_port.getText().toString();
                DRAW_CATEGORY = et_draw_category.getText().toString();

                try {
                    JSONFileManager.saveData(
                            MainActivity.this,
                            new JSONObject()
                                    .accumulate("host_address", HOST_ADDRESS)
                                    .accumulate("host_port", HOST_PORT)
                                    .accumulate("draw_category",DRAW_CATEGORY)
                                    .toString()
                    );
                    Toast.makeText(MainActivity.this,"Configuration Saved!",Toast.LENGTH_LONG).show();

                    create_activity_log("SETTING UPDATE"," New settings are applied! host: " + HOST_ADDRESS + " port: " + HOST_PORT);
                } catch(Exception e) {
                    Toast.makeText(MainActivity.this,e.getMessage(),Toast.LENGTH_LONG).show();
                }
            }
        });

        btn_send_to_server = findViewById(R.id.btn_send_to_server);
        btn_send_to_server.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                //Toast.makeText(MainActivity.this.getBaseContext(),"Calling Emit",Toast.LENGTH_SHORT).show();
                try {

                    Date dt = new java.util.Date();
                    SimpleDateFormat d = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
                    String mysql_date_string = d.format(dt);

                    JSONObject payload = new JSONObject()
                            .accumulate("origin", "09336435049")
                            .accumulate("content", et_send_to_server.getText().toString())
                            .accumulate("draw_category",DRAW_CATEGORY)
                            .accumulate("date", mysql_date_string);

                    create_activity_log("PUSHING CONTENTS TO SERVER (VIA BRIDGE)",payload.toString());
                    mSocket.emit("push_messages", payload);


                } catch(Exception e) {

                    create_activity_log("<!> PUSHING CONTENTS TO SERVER (VIA BRIDGE)",e.getMessage());
                    Toast.makeText(MainActivity.this,e.getMessage(),Toast.LENGTH_LONG).show();

                }
            }
        });

        btn_sync = findViewById(R.id.btn_sync);
        btn_sync.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                create_activity_log("SYNC LOCAL DATA","performing sync process");
                //btn_sync.setEnabled(false);

                int no_unsynced = countUnsyncedMessages();

                if(no_unsynced < 1) {

                    Toast.makeText(MainActivity.this, "All messages are already in sync!",Toast.LENGTH_LONG).show();
                    create_activity_log("SYNC LOCAL DATA","All messages are already in sync!");

                    return;
                }

                int no_error = syncMessages();

                if(no_error > 0) {
                    Toast.makeText(MainActivity.this, no_error + " entries were unable to sync successfully",Toast.LENGTH_LONG).show();
                    create_activity_log("<i> SYNC LOCAL DATA",no_error + " entries were unable to sync successfully");
                }

                updateSyncCounterWidget(countUnsyncedMessages());

                //btn_sync.setEnabled(true);
            }
        });

        TabHost tabs = findViewById(R.id.tabhost);
        tabs.setup();
        TabHost.TabSpec spec = tabs.newTabSpec("tag1");
        spec.setContent(R.id.tab1);
        spec.setIndicator("Status");
        tabs.addTab(spec);
        spec = tabs.newTabSpec("tag2");
        spec.setContent(R.id.tab2);
        spec.setIndicator("Config");
        tabs.addTab(spec);

    }

    private void initializeDatabase() {

        DB = openOrCreateDatabase("bettingserver.db",MODE_PRIVATE,null);
        DB.execSQL("CREATE TABLE IF NOT EXISTS messages (msgid INTEGER PRIMARY KEY AUTOINCREMENT, phone_number varchar(20), message varchar(1000), date_received varchar(50), is_confirmed boolean);");

        String db_contents = "";
        Cursor csr = DB.rawQuery("SELECT * FROM messages WHERE is_confirmed = ? ORDER BY msgid DESC",new String[]{"FALSE"});

        int ctr = 0;

        while(csr.moveToNext() && ctr < 10) {

            db_contents = db_contents + ("ID:" + csr.getString(0) + "\nORIGIN:"+ csr.getString(1) + "\nMSG:" + csr.getString(2) + "\nDATE:"+ csr.getString(3) + "\nIS_SYNCED:"+ csr.getString(4) + "\n\n");

            ctr++;
        }

        create_activity_log("DATABASE:","Successfully Initialized! \nDisplaying Latest Contents:\n" + db_contents);
    }

    private void initializeSockets() {

        btn_1.setClickable(false);
        btn_1.setText("CONNECTING");

        create_activity_log("SERVER LINKING","Initializing Socket Protocols...");

        if(mSocket != null) {
            mSocket.connect();

            if(mSocket.io().reconnectionDelay() > 10000) {
                mSocket.io().reconnectionDelay(2000);
            }

            return;
        }

        try {
            IO.Options opts = new IO.Options();
            opts.query = "auth_key=bridge123";

            mSocket = IO.socket("http://" + HOST_ADDRESS + ":" + HOST_PORT, opts);
            mSocket.io().reconnectionAttempts(5);
            mSocket.io().reconnectionDelay(2000);
        } catch (URISyntaxException e) {
            create_activity_log("<i> SERVER LINKING","URI Error " + e.getMessage());
            Toast.makeText(this,"URI Error",Toast.LENGTH_LONG).show();
        }

        mSocket.on(Socket.EVENT_DISCONNECT, new Emitter.Listener() {
            @Override
            public void call(Object... args) {
                MainActivity.this.runOnUiThread(new Runnable() {
                    @Override
                    public void run() {

                        btn_1.setClickable(false);
                        btn_1.setText("DISCONNECTED");
                        btn_1.setBackgroundColor(Color.rgb(255,0,0));
                        create_activity_log("SERVER LINKING:","Server link not responding...");
                    }
                });
            }
        });

        mSocket.on(Socket.EVENT_RECONNECT_FAILED, new Emitter.Listener() {
            @Override
            public void call(Object... args) {
                MainActivity.this.runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        btn_1.setClickable(true);
                        btn_1.setText("DISCONNECTED - RECONNECT?");
                        btn_1.setBackgroundColor(Color.rgb(255,0,0));
                        create_activity_log("SERVER LINKING:","Server link lost...");
                    }
                });
            }
        });

        mSocket.on(Socket.EVENT_RECONNECT, new Emitter.Listener() {
            @Override
            public void call(Object... args) {
                MainActivity.this.runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        btn_1.setClickable(false);
                        btn_1.setText("CONNECTED!");
                        btn_1.setBackgroundColor(Color.rgb(255,235,59));
                        create_activity_log("SERVER LINKING:","Server Link Established!");
                    }
                });
            }
        });

        mSocket.on(Socket.EVENT_RECONNECTING, new Emitter.Listener() {
            @Override
            public void call(Object... args) {
                MainActivity.this.runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        btn_1.setClickable(false);
                        btn_1.setText("RECONNECTING...");
                        btn_1.setBackgroundColor(Color.rgb(34,139,34));
                        create_activity_log("SERVER LINKING:","Attempting to reconnect to server...");
                    }
                });
            }
        });

        mSocket.on("request_all_sms", new Emitter.Listener() {
            @Override
            public void call(final Object... args) {
                 MainActivity.this.runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        JSONObject data = (JSONObject) args[0];
                        String payload;
                        try {
                            payload = data.getString("payload");
                        } catch (JSONException e) {

                            et_action_log.setText("\n An Error has occurred while receiving server request" + e.getMessage().toString());

                            return;
                        }

                        et_action_log.setText(et_action_log.getText().toString() + payload + "\n");

                        JSONArray resdata = getAllSms();

                        mSocket.emit("push_messages",resdata);
                    }
                });
            }
        });

        mSocket.on("push_message_feedback", new Emitter.Listener() {
            @Override
            public void call(final Object... args) {
                MainActivity.this.runOnUiThread(new Runnable() {
                    @Override
                    public void run() {

                        JSONObject data = (JSONObject) args[0];
                        create_activity_log("SERVER FEEDBACK","push_message_feedback json data\n" + data.toString());

                        mp.start();

                        try {

                            create_activity_log("UPDATING LOCAL DATABASE ENTRY","processing...");
                            ContentValues contents = new ContentValues();
                            contents.put("is_confirmed",true);

                            String datamessage = data.getJSONObject("payload").getJSONObject("original").getString("message");
                            String dataphone_number = data.getJSONObject("payload").getJSONObject("original").getString("phone_number");
                            String datadatereceived = data.getJSONObject("payload").getJSONObject("original").getString("date_received");

                            int affected_rows = DB.update("messages", contents," message = ? AND phone_number = ? AND date_received = ? AND is_confirmed = ?", new String[]{
                                    datamessage,
                                    dataphone_number,
                                    datadatereceived,
                                    "FALSE"
                            });

                            if (affected_rows < 1) {
                                create_activity_log("<!> UPDATING LOCAL DATABASE ENTRY","No Database Record Has Been Updated! No SMS Feedback Sent!");
                            } else {
                                create_activity_log("UPDATING LOCAL DATABASE ENTRY","ok...");
                            }

                            updateSyncCounterWidget(countUnsyncedMessages());

                            create_activity_log("SERVER MESSAGE",data.getString("server_message"));

                            if(data.getString("status").equals("success") && affected_rows > 0) {
                                smsManager.sendTextMessage(dataphone_number, null, data.getString("user_message"), null, null);
                                MainActivity.this.incrementBetCounterUIWidget();
                            } else if(affected_rows > 0){
                                if(dataphone_number.length() >= 11) {
                                    smsManager.sendTextMessage(dataphone_number, null, data.getString("user_message"), null, null);
                                }
                            } else {

                            }
                        } catch(Exception e) {
                            create_activity_log("<!> SERVER FEEDBACK","push_message_feedback\n" + e.getMessage());
                        }
                    }
                });
            }
        });

        mSocket.on("bridge_connected", new Emitter.Listener() {
            @Override
            public void call(final Object... args) {
                MainActivity.this.runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        create_activity_log("SERVER LINKING","Bridge Has Been Successfully Connected To Betting Server...");
                        btn_1.setText("CONNECTED!");
                        btn_1.setBackgroundColor(Color.rgb(255,235,59));
                    }
                });
            }
        });

        mSocket.on("send_message", new Emitter.Listener() {
            @Override
            public void call(final Object... args) {
                MainActivity.this.runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        try {
                            create_activity_log("SERVER COMMAND", "received an SMS job ... loading...");

                            JSONArray data = (JSONArray) args[0];

                            for(int x=0; x<data.length(); x++) {

                                JSONObject row = (JSONObject) data.get(x);

                                String datamessage = row.getString("message");
                                String dataphone_number = row.getString("phone_number");

                                create_activity_log("SERVER COMMAND", "sending message to \n" + dataphone_number + "...");
                                smsManager.sendTextMessage(dataphone_number, null, datamessage, null, null);
                                create_activity_log("SERVER COMMAND", "sending message to \n" + dataphone_number + " OK!");

                            }

                        } catch(Exception ex) {

                            JSONObject payload = new JSONObject();

                            try {

                                payload.accumulate("status", 0);
                                payload.accumulate("message", ex.getMessage());

                            } catch(JSONException e) {
                                create_activity_log("FATAL ERROR", "failed to emit socket message due to " + e.getMessage() + " please contact IT support");
                            }

                            create_activity_log("SEND MSG UTILITY", "failed to send message due to " + ex.getMessage() + " please contact IT support");
                            mSocket.emit("server_notification",payload);
                        }
                    }
                });
            }
        });

        mSocket.connect();

        create_activity_log("SERVER LINKING","Attempting to Connect To Betting Server...");
        mSocket.emit("bridge_attempt_connect",new JSONObject());

        btn_1.setText("CONNECTING");
    }

    public int countUnsyncedMessages() {
        Cursor csr = DB.rawQuery("SELECT * FROM messages WHERE is_confirmed = ?",new String[]{"FALSE"});
        return csr.getCount();
    }

    private int syncMessages() {
        btn_sync.setClickable(false);
        Toast.makeText(this,"Syncing Cached Messages to Server",Toast.LENGTH_LONG).show();
        int errors = 0;
        gCSR = DB.rawQuery("SELECT * FROM messages WHERE is_confirmed = ?",new String[]{"FALSE"});
        sync();
        btn_sync.setClickable(true);

        return errors;
    }
    public Cursor gCSR;

    private void sync() {

        if(gCSR.moveToNext()) {

            try {
                mSocket.emit("push_messages",
                        new JSONObject()
                                .accumulate("origin", gCSR.getString(1))
                                .accumulate("content", gCSR.getString(2))
                                .accumulate("draw_category",et_draw_category.getText())
                                .accumulate("date", gCSR.getString(3)),
                        new Ack() {

                            @Override
                            public void call(Object... args) {
                                sync();
                            }
                        });

            } catch(JSONException x) {

                Toast.makeText(this, x.getMessage(), Toast.LENGTH_LONG).show();
                return;
            }

        } else {
            return;
        }

    }

    public JSONArray getAllSms() {

        //Uri.parse("content://sms/inbox")

        //final String[] projection = { People._ID, People.NAME, People.NUMBER };
        //        final String sa1 = "%A%"; // contains an "A"
        //        cursor = resolver.query(People.CONTENT_URI, projection, People.NAME + " LIKE ?",
        //                new String[] { sa1 }, null);
        JSONArray returnobject = new JSONArray();

        Cursor c = getContentResolver().query(Telephony.Sms.CONTENT_URI, null, Telephony.Sms.ADDRESS + " = ? " , new String[] { "+639305774849" }, null);
        int totalSMS = 0;
        if (c != null) {
            totalSMS = c.getCount();

            Toast.makeText(MainActivity.this, "" + totalSMS, Toast.LENGTH_LONG).show();

            if (c.moveToNext()) {
                for (int j = 0; j < totalSMS; j++) {
                    String smsDate = c.getString(c.getColumnIndexOrThrow(Telephony.Sms.READ));
                    String number = c.getString(c.getColumnIndexOrThrow(Telephony.Sms.ADDRESS));
                    String body = c.getString(c.getColumnIndexOrThrow(Telephony.Sms.BODY));
                    Date dateFormat= new Date(Long.valueOf(smsDate));
                    String type;
                    switch (Integer.parseInt(c.getString(c.getColumnIndexOrThrow(Telephony.Sms.TYPE)))) {
                        case Telephony.Sms.MESSAGE_TYPE_INBOX:
                            type = "inbox";
                            break;
                        case Telephony.Sms.MESSAGE_TYPE_SENT:
                            type = "sent";
                            break;
                        case Telephony.Sms.MESSAGE_TYPE_OUTBOX:
                            type = "outbox";
                            break;
                        default:
                            break;
                    }

                    try {
                        returnobject.put(new JSONObject().accumulate("number", number).accumulate("body", body));
                    } catch (JSONException e) {

                    }

                    //Toast.makeText(this, number + "\n\n" + body, Toast.LENGTH_SHORT).show();

                    c.moveToNext();
                }
            }


            // c.close();

        } else {
            Toast.makeText(this, "No message to show!", Toast.LENGTH_SHORT).show();
        }

        return returnobject;
    }

    public void appendLog(String text) {
        File logFile = new File(Environment.getExternalStorageDirectory().toString() + "/bridgelog.txt");

        if (!logFile.exists())
        {
            try
            {
                logFile.createNewFile();
            }
            catch (IOException e)
            {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
        }
        try
        {
            //BufferedWriter for performance, true to set append to file flag
            BufferedWriter buf = new BufferedWriter(new FileWriter(logFile, true));
            buf.append(text);
            buf.newLine();
            buf.close();
        }
        catch (IOException e)
        {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }

    private void initializeBridgeConfigFromServer() {
        try {
            mSocket.emit("request_config", new JSONObject().accumulate("RECEIVER_NUMBER", "09337435049"));
        } catch(JSONException e) {

        }
    }

    public void incrementBetCounterUIWidget() {

        Integer val = Integer.parseInt(tv_no_bets.getText().toString());
        val += 1;

        tv_no_bets.setText("" + val);

        // Add Implementation to follow 00002 format
    }

    public void updateSyncCounterWidget(int val) {
        tv_unsynced_bets.setText("" + val);
    }

    public void create_activity_log(String log_title,String log_msg) {

        DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
        Date date = new Date();
        String ddd = dateFormat.format(date);

        et_action_log.setText(log_title + ":\n" + log_msg + "\n\n" + et_action_log.getText().toString());

        appendLog(log_title + "(" + ddd + "):\n" + log_msg + "\n\n");
    }

    private SmsManager smsManager;
    private static MediaPlayer mp;
    private static SMSReceiver sr;
    private String HOST_ADDRESS = "192.168.254.3";
    private String HOST_PORT = "3001";
    private String DRAW_CATEGORY = "stl";
    public Socket mSocket;
    public SQLiteDatabase DB;
    private Button btn_view_logs;
    private Button btn_1;
    private Button btn_send_to_server;
    private Button btn_save_settings;
    private Button btn_sync;
    private Button btn_clear_app_db_cache;
    private EditText et_send_to_server;
    public EditText et_action_log;
    private EditText et_host_address;
    private EditText et_host_port;
    public EditText et_draw_category;
    private TextView tv_unsynced_bets;
    private TextView tv_no_bets;
}

