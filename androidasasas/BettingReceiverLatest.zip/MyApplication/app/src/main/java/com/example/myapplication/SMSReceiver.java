package com.example.myapplication;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.*;

import android.os.Bundle;
import android.telephony.SmsMessage;
import android.widget.Toast;

import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;


public class SMSReceiver extends BroadcastReceiver {

    private MainActivity ma; //a reference to activity's context

    public SMSReceiver(MainActivity maContext) {
        Toast.makeText(maContext, "App Listening For Broadcast Message", Toast.LENGTH_LONG).show();
        ma=maContext;
        ma.create_activity_log("STARTUP","SMS Listener Initialized...");
    }

    @Override
    public void onReceive(Context context, Intent intent) {

        final Bundle bundle = intent.getExtras();

        try {
            if (bundle != null) {

                final Object[] pdusObj = (Object[]) bundle.get("pdus");
                //Toast.makeText(context, "" + pdusObj.length, Toast.LENGTH_LONG).show();

                ma.create_activity_log("SMS RECEIVED","pdusObj.length = " + pdusObj.length);

                for (int i = 0; i < pdusObj.length; i++) {

                    SmsMessage currentMessage = SmsMessage.createFromPdu((byte[]) pdusObj[i]);
                    String phoneNumber = currentMessage.getDisplayOriginatingAddress();
                    String message = currentMessage.getDisplayMessageBody();

                    Calendar calendar = Calendar.getInstance();
                    calendar.setTimeInMillis(currentMessage.getTimestampMillis());

                    Date dt = new java.util.Date();

//                    int date = calendar.get(Calendar.DATE);
//                    int hour = calendar.get(Calendar.HOUR_OF_DAY);
//                    int minute = calendar.get(Calendar.MINUTE);
//                    int second = calendar.get(Calendar.SECOND);

                    SimpleDateFormat d = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
                    String mysql_date_string = d.format(dt);

                    ma.create_activity_log("SCANNING CONTENTS","Origin: " + phoneNumber + "\nMsg: " + message + "\nDateTime: " + mysql_date_string);

                    try {

                        ma.create_activity_log("CREATING LOCAL DATABASE ENTRY","processing...");
                        ma.DB.execSQL("INSERT INTO messages ( phone_number, message, date_received, is_confirmed) VALUES (?,?,?,?)", new String[]{
                                phoneNumber,
                                message,
                                mysql_date_string,
                                "FALSE"
                        });
                        ma.create_activity_log("CREATING LOCAL DATABASE ENTRY","ok... message set as unsynced");

                        ma.updateSyncCounterWidget(ma.countUnsyncedMessages());

                        JSONObject payload = new JSONObject()
                                .accumulate("origin",phoneNumber)
                                .accumulate("content",message)
                                .accumulate("draw_category",ma.et_draw_category.getText())
                                .accumulate("date",mysql_date_string);

                        ma.create_activity_log("PUSHING CONTENTS TO SERVER","json object:\n" + payload.toString() + "\nnow awaiting confirmation...");

                        ma.mSocket.emit("push_messages", payload);

                    } catch (Exception e) {

                        ma.create_activity_log("<SMS RECEIVER ERROR>",e.getMessage().toString());

                    }
                }
            } else {
                ma.create_activity_log("<SMS RECEIVER ERROR>","null bundle");
            }
        } catch (Exception e) {

            ma.create_activity_log("<SMS RECEIVER ERROR>","outer try \n"+e.getMessage());
        }
    }

}
